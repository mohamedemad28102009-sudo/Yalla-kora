import express from "express";
import cors from "cors";
import helmet from "helmet";

import matchesRoutes from "./routes/matches.routes.js";

const app = express();

app.use(cors());
app.use(helmet());
app.use(express.json());

app.use("/api/matches", matchesRoutes);

export default app;
