import { apiFootball } from "../services/apiFootball.js";

export const liveMatches = async (req, res) => {
  const data = await apiFootball("/fixtures?live=all", process.env.API_FOOTBALL_KEY);
  if (!data) return res.json({ error: "no-data" });
  res.json(data);
};
