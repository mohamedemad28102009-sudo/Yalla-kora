import express from "express";
import { liveMatches } from "../controllers/matches.controller.js";

const router = express.Router();

router.get("/live", liveMatches);

export default router;
