import axios from "axios";

const BASE = "https://v3.football.api-sports.io";

export const apiFootball = async (url, key) => {
  try {
    const res = await axios.get(BASE + url, {
      headers: { "x-apisports-key": key }
    });
    return res.data;
  } catch {
    return null;
  }
};
