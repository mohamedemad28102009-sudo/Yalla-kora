export const getLiveMatches = async () => {
  const res = await fetch("http://localhost:5000/api/matches/live");
  return res.json();
};
