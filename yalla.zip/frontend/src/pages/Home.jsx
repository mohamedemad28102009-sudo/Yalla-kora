import { useEffect, useState } from "react";
import { getLiveMatches } from "../api";

export default function Home() {
  const [data, setData] = useState([]);

  useEffect(() => {
    load();
  }, []);

  const load = async () => {
    const res = await getLiveMatches();
    if (res?.response) setData(res.response);
  };

  return (
    <div style={{ padding: 20, direction: "rtl" }}>
      <h1>⚽ المباريات المباشرة</h1>

      {data.map((m, i) => (
        <div key={i} style={{ border: "1px solid #ddd", margin: 10, padding: 10 }}>
          <h3>{m.teams.home.name} 🆚 {m.teams.away.name}</h3>
          <p>{m.league.name}</p>
        </div>
      ))}
    </div>
  );
}
